<?php
require_once '../config.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }

// Hitung total data
$total_orang = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f6f9; display: flex; }
        .sidebar { width: 250px; background: #2c3e50; color: white; height: 100vh; padding: 20px; box-sizing: border-box; }
        .sidebar h3 { text-align: center; margin-bottom: 30px; }
        .sidebar a { display: block; color: #bdc3c7; padding: 12px; text-decoration: none; border-radius: 4px; margin-bottom: 10px; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; color: white; }
        .main-content { flex: 1; padding: 30px; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
        .cards { display: flex; gap: 20px; margin-top: 20px; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); flex: 1; text-align: center; }
        .card h1 { font-size: 48px; color: #007bff; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
        th { background-color: #007bff; color: white; }
        .btn { padding: 6px 12px; text-decoration: none; border-radius: 4px; font-size: 14px; color: white; display: inline-block; }
        .btn-add { background: #28a745; margin-bottom: 15px; padding: 10px 15px; }
        .btn-edit { background: #ffc107; color: #333; }
        .btn-delete { background: #dc3545; }
        .avatar { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
    </style>
</head>
<body>

<div class="sidebar">
    <h3>AR Personal Admin</h3>
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="../index.php" target="_blank">Buka Kamera AR</a>
    <a href="logout.php" style="color: #e74c3c; margin-top: 50px;">Logout</a>
</div>

<div class="main-content">
    <div class="header">
        <h2>Selamat Datang, <?= htmlspecialchars($_SESSION['admin_username']) ?></h2>
    </div>

    <div class="cards">
        <div class="card">
            <h3>Total Data Pengguna AR</h3>
            <h1><?= $total_orang ?></h1>
        </div>
    </div>

    <h2 style="margin-top: 40px;">Kelola Data Personil</h2>
    <a href="tambah.php" class="btn btn-add">+ Tambah Data Baru</a>

    <table>
        <thead>
            <tr>
                <th>Foto</th>
                <th>Nama</th>
                <th>NIM</th>
                <th>Prodi</th>
                <th>Email</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $pdo->query("SELECT * FROM users ORDER BY id DESC");
            while($row = $stmt->fetch()):
            ?>
            <tr>
                <td><img src="../uploads/<?= $row['foto'] ?>" class="avatar" alt="Profil"></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['nim']) ?></td>
                <td><?= htmlspecialchars($row['prodi']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-edit">Edit</a>
                    <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-delete" onclick="return confirm('Hapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>