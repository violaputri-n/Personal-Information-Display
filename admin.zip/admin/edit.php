<?php
require_once '../config.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }

$id = $_GET['id'] ?? null;
if(!$id) { header("Location: dashboard.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();
if(!$user) { die("Data tidak ditemukan"); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $prodi = $_POST['prodi'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $descriptor = $_POST['descriptor'];
    
    $new_foto_name = $user['foto']; // Default foto lama

    if ($_FILES['foto']['name'] != '') {
        $foto_name = $_FILES['foto']['name'];
        $foto_tmp = $_FILES['foto']['tmp_name'];
        $ext = pathinfo($foto_name, PATHINFO_EXTENSION);
        $new_foto_name = time() . '_' . $nim . '.' . $ext;
        move_uploaded_file($foto_tmp, "../uploads/" . $new_foto_name);
        
        // Hapus foto lama jika ada
        if(file_exists("../uploads/" . $user['foto'])) {
            unlink("../uploads/" . $user['foto']);
        }
    }
    
    // Update data, jika descriptor baru kosong (karena foto tidak diganti), tetap pakai yang lama
    if(empty($descriptor)) {
        $stmt = $pdo->prepare("UPDATE users SET nama=?, nim=?, prodi=?, email=?, no_hp=?, foto=? WHERE id=?");
        $stmt->execute([$nama, $nim, $prodi, $email, $no_hp, $new_foto_name, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET nama=?, nim=?, prodi=?, email=?, no_hp=?, foto=?, descriptor=? WHERE id=?");
        $stmt->execute([$nama, $nim, $prodi, $email, $no_hp, $new_foto_name, $descriptor, $id]);
    }
    
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Pengguna</title>
    <script src="../js/face-api.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 40px; }
        .form-container { background: white; max-width: 600px; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow:0 2px 10px rgba(0,0,0,0.05); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="file"] { width:100%; padding: 10px; border: 1px solid #ddd; border-radius:4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; color: white; font-size: 16px; }
        .btn-primary { background: #007bff; }
        #status-msg { color: #e67e22; font-weight: bold; margin-bottom: 10px; }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Edit Data Pengguna</h2>
    <div id="status-msg">Menggunakan Face AI Model lama (Kecuali Anda mengunggah foto baru).</div>
    
    <form id="userForm" action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="descriptor" id="descriptor_input">

        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" required>
        </div>
        <div class="form-group">
            <label>NIM</label>
            <input type="text" name="nim" value="<?= htmlspecialchars($user['nim']) ?>" required>
        </div>
        <div class="form-group">
            <label>Program Studi</label>
            <input type="text" name="prodi" value="<?= htmlspecialchars($user['prodi']) ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>
        <div class="form-group">
            <label>Nomor Telepon</label>
            <input type="text" name="no_hp" value="<?= htmlspecialchars($user['no_hp']) ?>" required>
        </div>
        <div class="form-group">
            <label>Ganti Foto Wajah (Kosongkan jika tidak ingin diubah)</label>
            <input type="file" id="foto_input" name="foto" accept="image/*" disabled>
            <p><small>Foto saat ini: <?= $user['foto'] ?></small></p>
        </div>
        
        <button type="submit" id="submit_btn" class="btn btn-primary">Update Data</button>
        <a href="dashboard.php" style="margin-left: 15px; color: #666;">Batal</a>
    </form>
</div>

<script>
    async function initFaceApi() {
        try {
            await faceapi.nets.ssdMobilenetv1.loadFromUri('../models');
            await faceapi.nets.faceLandmark68Net.loadFromUri('../models');
            await faceapi.nets.faceRecognitionNet.loadFromUri('../models');
            document.getElementById('status-msg').innerText = "Face AI Siap! Unggah foto baru jika ingin memperbarui deteksi.";
            document.getElementById('foto_input').disabled = false;
        } catch (e) {
            console.error(e);
        }
    }

    document.getElementById('foto_input').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if(!file) return;

        document.getElementById('status-msg').innerText = "Sedang memproses struktur wajah baru...";
        document.getElementById('submit_btn').disabled = true;

        const img = await faceapi.bufferToImage(file);
        const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();

        if (detection) {
            const descriptorArray = Array.from(detection.descriptor);
            document.getElementById('descriptor_input').value = JSON.stringify(descriptorArray);
            document.getElementById('status-msg').innerText = "✓ Struktur wajah baru siap disimpan.";
            document.getElementById('submit_btn').disabled = false;
        } else {
            document.getElementById('status-msg').innerText = "❌ Wajah tidak terdeteksi! Gunakan foto lain.";
            e.target.value = "";
            document.getElementById('submit_btn').disabled = false;
        }
    });

    initFaceApi();
</script>
</body>
</html>