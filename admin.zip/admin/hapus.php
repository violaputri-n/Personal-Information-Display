<?php
require_once '../config.php';
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }

$id = $_GET['id'] ?? null;
if($id) {
    // Ambil info nama file foto sebelum dihapus dari DB
    $stmt = $pdo->prepare("SELECT foto FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if($user) {
        if(file_exists("../uploads/" . $user['foto'])) {
            unlink("../uploads/" . $user['foto']);
        }
        
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
    }
}
header("Location: dashboard.php");
exit;
?>