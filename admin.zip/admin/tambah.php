<?php
require_once '../config.php';

// Proteksi halaman: Jika belum login, tendang balik ke login.php
if (!isset($_SESSION['admin_logged_in'])) { 
    header("Location: login.php"); 
    exit; 
}

$error_msg = '';

// Proses ketika tombol "Simpan Data" diklik
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);
    $nim = trim($_POST['nim']);
    $prodi = trim($_POST['prodi']);
    $email = trim($_POST['email']);
    $no_hp = trim($_POST['no_hp']);
    $descriptor = $_POST['descriptor']; // String matriks JSON koordinat wajah dari Face-API
    
    // Validasi apakah descriptor wajah kosong
    if (empty($descriptor) || $descriptor === "[]") {
        $error_msg = "Gagal menyimpan! Wajah pada foto belum diekstraksi oleh AI.";
    } else {
        // Proses upload file foto fisik ke folder /uploads/
        $foto_name = $_FILES['foto']['name'];
        $foto_tmp = $_FILES['foto']['tmp_name'];
        $ext = strtolower(pathinfo($foto_name, PATHINFO_EXTENSION));
        
        // Buat nama foto baru yang unik (contoh: 171829381_221001.jpg)
        $new_foto_name = time() . '_' . $nim . '.' . $ext;
        
        // Pastikan folder uploads ada, jika belum buat otomatis
        if (!is_dir('../uploads')) {
            mkdir('../uploads', 0777, true);
        }

        if (move_uploaded_file($foto_tmp, "../uploads/" . $new_foto_name)) {
            try {
                // Simpan data lengkap ke dalam database MySQL
                $stmt = $pdo->prepare("INSERT INTO users (nama, nim, prodi, email, no_hp, foto, descriptor) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nama, $nim, $prodi, $email, $no_hp, $new_foto_name, $descriptor]);
                
                // Jika sukses, kembalikan ke halaman dashboard
                header("Location: dashboard.php");
                exit;
            } catch (PDOException $e) {
                $error_msg = "Gagal menyimpan ke database: " . $e->getMessage();
            }
        } else {
            $error_msg = "Gagal mengunggah gambar ke folder server.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Personil - AR Face Recognition</title>
    <script src="../js/face-api.min.js"></script>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f6f9; margin: 0; padding: 40px; display: flex; justify-content: center; }
        .form-container { background: white; width: 100%; max-width: 600px; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }
        h2 { margin-top: 0; color: #2c3e50; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #4a5568; }
        input[type="text"], input[type="email"], input[type="file"] { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
        input:focus { border-color: #007bff; outline: none; box-shadow: 0 0 0 3px rgba(0,123,255,0.15); }
        .btn-group { display: flex; gap: 10px; margin-top: 30px; }
        .btn { padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold; text-decoration: none; text-align: center; }
        .btn-primary { background: #007bff; color: white; flex: 1; }
        .btn-primary:disabled { background: #94a3b8; cursor: not-allowed; }
        .btn-secondary { background: #e2e8f0; color: #475569; }
        #status-box { padding: 12px; border-radius: 6px; font-weight: bold; margin-bottom: 20px; font-size: 14px; background: #fef3c7; color: #d97706; border: 1px solid #fcd34d; }
        .error-alert { background: #fee2e2; color: #dc2626; padding: 12px; border-radius: 6px; margin-bottom: 20px; font-weight: bold; border: 1px solid #fca5a5; }
        #preview-img { max-width: 200px; max-height: 200px; margin-top: 10px; display: none; border-radius: 8px; border: 2px solid #ddd; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Tambah Pengguna Baru (Registrasi AR)</h2>
    
    <div id="status-box">Sedang memuat AI Engine (Face-API Model)... Mohon tunggu.</div>

    <?php if(!empty($error_msg)): ?>
        <div class="error-alert"><?= $error_msg ?></div>
    <?php endif; ?>
    
    <form id="addForm" action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="descriptor" id="descriptor_input">

        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" placeholder="Contoh: Ahmad Fauzi" required>
        </div>
        
        <div class="form-group">
            <label>NIM</label>
            <input type="text" name="nim" placeholder="Contoh: 221001" required>
        </div>
        
        <div class="form-group">
            <label>Program Studi</label>
            <input type="text" name="prodi" placeholder="Contoh: Informatika" required>
        </div>
        
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Contoh: ahmad@gmail.com" required>
        </div>
        
        <div class="form-group">
            <label>Nomor Telepon / HP</label>
            <input type="text" name="no_hp" placeholder="Contoh: 081234567890" required>
        </div>
        
        <div class="form-group">
            <label>Pilih Foto Wajah Berwarna</label>
            <input type="file" id="foto_input" name="foto" accept="image/*" required disabled>
            <br>
            <img id="preview-img" alt="Pratinjau Foto">
        </div>
        
        <div class="btn-group">
            <button type="submit" id="submit_btn" class="btn btn-primary" disabled>Simpan Data</button>
            <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>

<script>
    const statusBox = document.getElementById('status-box');
    const fotoInput = document.getElementById('foto_input');
    const submitBtn = document.getElementById('submit_btn');
    const previewImg = document.getElementById('preview-img');
    const descriptorInput = document.getElementById('descriptor_input');

    // 1. Memuat model neural network biner dari folder /models/ secara lokal
    async function loadFaceModels() {
    try {
        await faceapi.nets.ssdMobilenetv1.loadFromUri('../models');
        await faceapi.nets.faceLandmark68Net.loadFromUri('../models');
        await faceapi.nets.faceRecognitionNet.loadFromUri('../models');

        statusBox.style.background = "#dcfce7";
        statusBox.style.color = "#15803d";
        statusBox.style.borderColor = "#bbf7d0";
        statusBox.innerText = "✓ AI Engine Siap!";

        fotoInput.disabled = false;

    } catch (error) {

        console.error("DETAIL ERROR:", error);

        statusBox.style.background = "#fee2e2";
        statusBox.style.color = "#b91c1c";
        statusBox.style.borderColor = "#fca5a5";
        statusBox.innerText = "❌ Gagal memuat model. Tekan F12 lalu lihat tab Console.";
    }
}

    // 2. Event Listener saat admin memilih file gambar dari komputernya
    fotoInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Tampilkan preview gambar di form
        previewImg.src = URL.createObjectURL(file);
        previewImg.style.display = "block";

        statusBox.style.background = "#fef3c7";
        statusBox.style.color = "#d97706";
        statusBox.style.borderColor = "#fcd34d";
        statusBox.innerText = "Sedang menganalisis biometrik wajah foto... Harap tunggu.";
        submitBtn.disabled = true;

        // Konversi file gambar menjadi objek HTML Image element
        const img = await faceapi.bufferToImage(file);
        
        // Jalankan ekstraksi face descriptor (128-bit floating point array)
        const detection = await faceapi.detectSingleFace(img)
                                      .withFaceLandmarks()
                                      .withFaceDescriptor();

        if (detection) {
            // Ubah Float32Array menjadi tipe array JavaScript biasa agar bisa di-stringify ke JSON
            const descriptorArray = Array.from(detection.descriptor);
            descriptorInput.value = JSON.stringify(descriptorArray);
            
            statusBox.style.background = "#dcfce7";
            statusBox.style.color = "#15803d";
            statusBox.style.borderColor = "#bbf7d0";
            statusBox.innerText = "✓ Wajah berhasil diekstraksi dan dikenali! Tombol simpan aktif.";
            submitBtn.disabled = false;
        } else {
            statusBox.style.background = "#fee2e2";
            statusBox.style.color = "#b91c1c";
            statusBox.style.borderColor = "#fca5a5";
            statusBox.innerText = "❌ Wajah tidak terdeteksi! Gunakan foto wajah yang tegak, jelas, dan terang.";
            descriptorInput.value = "";
            e.target.value = ""; // Reset input file
            previewImg.style.display = "none";
            submitBtn.disabled = true;
        }
    });

    // Jalankan pemuatan model saat script render awal
    loadFaceModels();
</script>
</body>
</html>