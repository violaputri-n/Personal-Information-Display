<?php
header('Content-Type: application/json');
require_once '../config.php';

try {
    // Mengambil semua data user dari database
    $stmt = $pdo->query("SELECT id, nama, nim, prodi, email, no_hp, foto, descriptor FROM users");
    $users = $stmt->fetchAll();
    
    // Mengubah string descriptor (JSON) kembali menjadi array sebelum dikirim ke frontend
    foreach ($users as &$user) {
        $user['descriptor'] = json_parse_descriptor($user['descriptor']);
    }
    
    echo json_encode(["status" => "success", "data" => $users]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}

// Fungsi helper untuk memastikan descriptor dibaca sebagai array float
function json_parse_descriptor($string) {
    $arr = json_decode($string, true);
    return is_array($arr) ? $arr : [];
}
?>