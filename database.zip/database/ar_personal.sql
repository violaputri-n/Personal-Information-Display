CREATE DATABASE IF NOT EXISTS ar_personal;
USE ar_personal;

-- Struktur tabel untuk admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Struktur tabel untuk users (data personil & face descriptor)
-- Descriptor disimpan sebagai TEXT karena berisi array dari 128 floating point numbers
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `nim` VARCHAR(20) NOT NULL UNIQUE,
  `prodi` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `no_hp` VARCHAR(20) NOT NULL,
  `foto` VARCHAR(255) NOT NULL,
  `descriptor` LONGTEXT NOT NULL, 
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert data admin default (Username: admin, Password: admin123 melalui password_hash)
INSERT INTO `admin` (`username`, `password`) VALUES 
('admin', 'admin123')
ON DUPLICATE KEY UPDATE id=id;

-- Insert 4 Data Awal Pengguna (Descriptor dikosongkan dulu, akan di-generate saat upload via admin atau diisi array dummy)
INSERT INTO `users` (`nama`, `nim`, `prodi`, `email`, `no_hp`, `foto`, `descriptor`) VALUES
('Viola Putri', '2315061014', 'Informatika', 'violaputri315@gmail.com', '081234567890', 'viola.jpg', '[]'),
('Najwa Aprisda', '2315061066', 'Sistem Informasi', 'najwaaprisda@gmail.com', '081234567891', 'najwa.jpg', '[]');